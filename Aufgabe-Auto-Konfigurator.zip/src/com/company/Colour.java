package com.company;

public enum Colour {

    // Variables
    BLACK,
    WHITE,
    GREY,
    Silver
}
