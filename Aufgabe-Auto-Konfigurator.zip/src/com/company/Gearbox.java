package com.company;

public enum Gearbox {

    // Variables
    AUTOMATIC,
    MANUAL
}
